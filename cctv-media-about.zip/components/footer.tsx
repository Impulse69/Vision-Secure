import Link from "next/link"
import { Mail, Phone, MapPin, Camera, Shield, Volume2 } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-card border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-sm">VS</span>
              </div>
              <span className="font-bold text-xl text-foreground">VisionSecure</span>
            </div>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Your trusted partner for CCTV security solutions, professional media production, and high-quality sound
              services.
            </p>
            <div className="flex space-x-4">
              <div className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center">
                <Shield className="h-5 w-5 text-primary" />
              </div>
              <div className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center">
                <Camera className="h-5 w-5 text-primary" />
              </div>
              <div className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center">
                <Volume2 className="h-5 w-5 text-primary" />
              </div>
            </div>
          </div>

          {/* Services */}
          <div className="space-y-4">
            <h3 className="font-semibold text-foreground">Services</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/services/cctv" className="text-muted-foreground hover:text-primary transition-colors">
                  CCTV Installation
                </Link>
              </li>
              <li>
                <Link href="/services/media" className="text-muted-foreground hover:text-primary transition-colors">
                  Media Production
                </Link>
              </li>
              <li>
                <Link href="/services/sound" className="text-muted-foreground hover:text-primary transition-colors">
                  Sound Production
                </Link>
              </li>
              <li>
                <Link
                  href="/services/maintenance"
                  className="text-muted-foreground hover:text-primary transition-colors"
                >
                  Maintenance & Support
                </Link>
              </li>
            </ul>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="font-semibold text-foreground">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/about" className="text-muted-foreground hover:text-primary transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/portfolio" className="text-muted-foreground hover:text-primary transition-colors">
                  Portfolio
                </Link>
              </li>
              <li>
                <Link href="/testimonials" className="text-muted-foreground hover:text-primary transition-colors">
                  Testimonials
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-muted-foreground hover:text-primary transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h3 className="font-semibold text-foreground">Contact</h3>
            <div className="space-y-3 text-sm">
              <div className="flex items-center space-x-3">
                <Phone className="h-4 w-4 text-primary" />
                <span className="text-muted-foreground">+1 (555) 123-4567</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-4 w-4 text-primary" />
                <span className="text-muted-foreground">info@visionsecure.com</span>
              </div>
              <div className="flex items-start space-x-3">
                <MapPin className="h-4 w-4 text-primary mt-0.5" />
                <span className="text-muted-foreground">
                  123 Security Ave
                  <br />
                  Tech City, TC 12345
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-border mt-8 pt-8 text-center">
          <p className="text-muted-foreground text-sm">
            © 2024 VisionSecure. All rights reserved. | Privacy Policy | Terms of Service
          </p>
        </div>
      </div>
    </footer>
  )
}
