"use client"

import type React from "react"

import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { MapPin, Phone, Mail, Clock, MessageSquare, Send } from "lucide-react"
import { useEffect, useRef, useState } from "react"

export default function ContactPage() {
  const heroRef = useRef<HTMLElement>(null)
  const formRef = useRef<HTMLElement>(null)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    service: "",
    message: "",
  })

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in-up")
          }
        })
      },
      { threshold: 0.1 },
    )

    if (heroRef.current) observer.observe(heroRef.current)
    if (formRef.current) observer.observe(formRef.current)

    return () => observer.disconnect()
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission here
    console.log("Form submitted:", formData)
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />

      {/* Hero Section */}
      <section ref={heroRef} className="pt-24 pb-16 px-4 sm:px-6 lg:px-8 opacity-0">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6 text-balance">
            Let's bring your
            <span className="text-primary block">vision to life</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8 text-pretty">
            Ready to secure your space or create something iconic? Get in touch with our team and let's discuss how we
            can help transform your ideas into reality.
          </p>
        </div>
      </section>

      {/* Contact Form & Info */}
      <section ref={formRef} className="py-16 px-4 sm:px-6 lg:px-8 opacity-0">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <Card className="bg-card/50 backdrop-blur-sm">
              <CardContent className="p-8">
                <div className="flex items-center mb-6">
                  <MessageSquare className="w-6 h-6 text-primary mr-3" />
                  <h2 className="text-2xl font-bold text-foreground">Send us a message</h2>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name *</Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) => handleInputChange("name", e.target.value)}
                        placeholder="Your full name"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address *</Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => handleInputChange("email", e.target.value)}
                        placeholder="your@email.com"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input
                        id="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => handleInputChange("phone", e.target.value)}
                        placeholder="+1 (555) 123-4567"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="service">Service Interested In *</Label>
                      <Select onValueChange={(value) => handleInputChange("service", value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a service" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="cctv">CCTV Security Systems</SelectItem>
                          <SelectItem value="media">Media Production</SelectItem>
                          <SelectItem value="sound">Sound Production</SelectItem>
                          <SelectItem value="multiple">Multiple Services</SelectItem>
                          <SelectItem value="consultation">General Consultation</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message">Project Details *</Label>
                    <Textarea
                      id="message"
                      value={formData.message}
                      onChange={(e) => handleInputChange("message", e.target.value)}
                      placeholder="Tell us about your project, timeline, and any specific requirements..."
                      rows={6}
                      required
                    />
                  </div>

                  <Button type="submit" size="lg" className="w-full">
                    <Send className="w-4 h-4 mr-2" />
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Contact Information */}
            <div className="space-y-8">
              <div>
                <h2 className="text-2xl font-bold text-foreground mb-6">Get in touch</h2>
                <p className="text-muted-foreground leading-relaxed mb-8">
                  We're here to help you every step of the way. Whether you need a security consultation, media
                  production services, or sound engineering expertise, our team is ready to deliver exceptional results.
                </p>
              </div>

              <div className="space-y-6">
                <Card className="bg-card/30 backdrop-blur-sm">
                  <CardContent className="p-6">
                    <div className="flex items-start">
                      <MapPin className="w-6 h-6 text-primary mr-4 mt-1 flex-shrink-0" />
                      <div>
                        <h3 className="font-semibold text-foreground mb-1">Our Location</h3>
                        <p className="text-muted-foreground text-sm">
                          123 Technology Drive
                          <br />
                          Innovation District
                          <br />
                          Tech City, TC 12345
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-card/30 backdrop-blur-sm">
                  <CardContent className="p-6">
                    <div className="flex items-start">
                      <Phone className="w-6 h-6 text-primary mr-4 mt-1 flex-shrink-0" />
                      <div>
                        <h3 className="font-semibold text-foreground mb-1">Phone & Emergency</h3>
                        <p className="text-muted-foreground text-sm">
                          Main: +1 (555) 123-4567
                          <br />
                          Emergency: +1 (555) 911-HELP
                          <br />
                          Toll-free: 1-800-VISION-1
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-card/30 backdrop-blur-sm">
                  <CardContent className="p-6">
                    <div className="flex items-start">
                      <Mail className="w-6 h-6 text-primary mr-4 mt-1 flex-shrink-0" />
                      <div>
                        <h3 className="font-semibold text-foreground mb-1">Email Contacts</h3>
                        <p className="text-muted-foreground text-sm">
                          General: info@visionsecure.com
                          <br />
                          Sales: sales@visionsecure.com
                          <br />
                          Support: support@visionsecure.com
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-card/30 backdrop-blur-sm">
                  <CardContent className="p-6">
                    <div className="flex items-start">
                      <Clock className="w-6 h-6 text-primary mr-4 mt-1 flex-shrink-0" />
                      <div>
                        <h3 className="font-semibold text-foreground mb-1">Business Hours</h3>
                        <p className="text-muted-foreground text-sm">
                          Monday - Friday: 8:00 AM - 6:00 PM
                          <br />
                          Saturday: 9:00 AM - 4:00 PM
                          <br />
                          Sunday: Emergency calls only
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="bg-primary/10 rounded-lg p-6 border border-primary/20">
                <h3 className="font-semibold text-foreground mb-2">Quick Response Guarantee</h3>
                <p className="text-muted-foreground text-sm">
                  We respond to all inquiries within 2 hours during business hours. For urgent security matters, call
                  our emergency line for immediate assistance.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-card/20">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Frequently Asked Questions</h2>
            <p className="text-lg text-muted-foreground">
              Quick answers to common questions about our services and process.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="font-semibold text-foreground mb-2">How quickly can you start my project?</h3>
              <p className="text-muted-foreground text-sm mb-6">
                Most projects can begin within 1-2 weeks of contract signing. Emergency security installations can often
                start within 24-48 hours.
              </p>
            </div>

            <div>
              <h3 className="font-semibold text-foreground mb-2">Do you provide ongoing support?</h3>
              <p className="text-muted-foreground text-sm mb-6">
                Yes, we offer comprehensive maintenance packages and 24/7 support for all our security systems and
                ongoing support for media projects.
              </p>
            </div>

            <div>
              <h3 className="font-semibold text-foreground mb-2">What's included in a consultation?</h3>
              <p className="text-muted-foreground text-sm mb-6">
                Our free consultation includes site assessment, needs analysis, custom solution design, and detailed
                project proposal with transparent pricing.
              </p>
            </div>

            <div>
              <h3 className="font-semibold text-foreground mb-2">Do you work with insurance companies?</h3>
              <p className="text-muted-foreground text-sm mb-6">
                Yes, we work directly with insurance providers and can help you navigate coverage options for security
                system installations and upgrades.
              </p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
