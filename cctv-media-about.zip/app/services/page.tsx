"use client"

import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Shield, Camera, Volume2, CheckCircle, Star, Users, Clock, Award } from "lucide-react"
import Link from "next/link"
import { useEffect, useRef } from "react"

export default function ServicesPage() {
  const heroRef = useRef<HTMLElement>(null)
  const servicesRef = useRef<HTMLElement>(null)
  const featuresRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in-up")
          }
        })
      },
      { threshold: 0.1 },
    )

    if (heroRef.current) observer.observe(heroRef.current)
    if (servicesRef.current) observer.observe(servicesRef.current)
    if (featuresRef.current) observer.observe(featuresRef.current)

    return () => observer.disconnect()
  }, [])

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />

      {/* Hero Section */}
      <section ref={heroRef} className="pt-24 pb-16 px-4 sm:px-6 lg:px-8 opacity-0">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6 text-balance">
            Where technology meets
            <span className="text-primary block">professional excellence</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8 text-pretty">
            Our comprehensive services span security, media production, and sound engineering. Explore how we help
            businesses transform their vision into reality.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild>
              <Link href="/contact">Get Started</Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/portfolio">View Our Work</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Main Services Grid */}
      <section ref={servicesRef} className="py-16 px-4 sm:px-6 lg:px-8 opacity-0">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Our Services</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Three core specializations that drive business transformation at every stage of the process.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* CCTV Security */}
            <Card className="group hover:border-primary/50 transition-all duration-300 bg-card/50 backdrop-blur-sm">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-colors">
                  <Shield className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-4">CCTV Security Systems</h3>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  Advanced surveillance solutions with cutting-edge technology. We design, install, and maintain
                  comprehensive security systems tailored to your specific needs.
                </p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center text-sm text-muted-foreground">
                    <CheckCircle className="w-4 h-4 text-primary mr-3 flex-shrink-0" />
                    4K Ultra HD camera systems
                  </li>
                  <li className="flex items-center text-sm text-muted-foreground">
                    <CheckCircle className="w-4 h-4 text-primary mr-3 flex-shrink-0" />
                    Remote monitoring capabilities
                  </li>
                  <li className="flex items-center text-sm text-muted-foreground">
                    <CheckCircle className="w-4 h-4 text-primary mr-3 flex-shrink-0" />
                    Motion detection & alerts
                  </li>
                  <li className="flex items-center text-sm text-muted-foreground">
                    <CheckCircle className="w-4 h-4 text-primary mr-3 flex-shrink-0" />
                    Cloud storage solutions
                  </li>
                </ul>
                <Button className="w-full bg-transparent" variant="outline">
                  Learn More
                </Button>
              </CardContent>
            </Card>

            {/* Media Production */}
            <Card className="group hover:border-primary/50 transition-all duration-300 bg-card/50 backdrop-blur-sm">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-colors">
                  <Camera className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-4">Media Production</h3>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  Professional videography and photography services that capture your brand's essence. From corporate
                  events to marketing content, we bring your vision to life.
                </p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center text-sm text-muted-foreground">
                    <CheckCircle className="w-4 h-4 text-primary mr-3 flex-shrink-0" />
                    Corporate videography
                  </li>
                  <li className="flex items-center text-sm text-muted-foreground">
                    <CheckCircle className="w-4 h-4 text-primary mr-3 flex-shrink-0" />
                    Event photography
                  </li>
                  <li className="flex items-center text-sm text-muted-foreground">
                    <CheckCircle className="w-4 h-4 text-primary mr-3 flex-shrink-0" />
                    Marketing content creation
                  </li>
                  <li className="flex items-center text-sm text-muted-foreground">
                    <CheckCircle className="w-4 h-4 text-primary mr-3 flex-shrink-0" />
                    Post-production editing
                  </li>
                </ul>
                <Button className="w-full bg-transparent" variant="outline">
                  Learn More
                </Button>
              </CardContent>
            </Card>

            {/* Sound Production */}
            <Card className="group hover:border-primary/50 transition-all duration-300 bg-card/50 backdrop-blur-sm">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-colors">
                  <Volume2 className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-4">Sound Production</h3>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  High-quality audio solutions for events, recordings, and installations. Our expertise ensures
                  crystal-clear sound that enhances every experience.
                </p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center text-sm text-muted-foreground">
                    <CheckCircle className="w-4 h-4 text-primary mr-3 flex-shrink-0" />
                    Live event sound systems
                  </li>
                  <li className="flex items-center text-sm text-muted-foreground">
                    <CheckCircle className="w-4 h-4 text-primary mr-3 flex-shrink-0" />
                    Studio recording services
                  </li>
                  <li className="flex items-center text-sm text-muted-foreground">
                    <CheckCircle className="w-4 h-4 text-primary mr-3 flex-shrink-0" />
                    Audio post-production
                  </li>
                  <li className="flex items-center text-sm text-muted-foreground">
                    <CheckCircle className="w-4 h-4 text-primary mr-3 flex-shrink-0" />
                    Equipment rental
                  </li>
                </ul>
                <Button className="w-full bg-transparent" variant="outline">
                  Learn More
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section ref={featuresRef} className="py-16 px-4 sm:px-6 lg:px-8 bg-card/20 opacity-0">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Why Choose VisionSecure</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Our approach combines innovation, reliability, and excellence to deliver results that exceed expectations.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center group">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/20 transition-colors">
                <Star className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-2">Premium Quality</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                We use only the finest equipment and maintain the highest standards in every project we undertake.
              </p>
            </div>

            <div className="text-center group">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/20 transition-colors">
                <Users className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-2">Expert Team</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                Our certified professionals bring years of experience and passion to every project.
              </p>
            </div>

            <div className="text-center group">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/20 transition-colors">
                <Clock className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-2">Timely Delivery</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                We respect your time and ensure all projects are completed on schedule without compromising quality.
              </p>
            </div>

            <div className="text-center group">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/20 transition-colors">
                <Award className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-2">Proven Results</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                Our track record speaks for itself with hundreds of satisfied clients and successful projects.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6 text-balance">
            Ready to transform your business with professional services?
          </h2>
          <p className="text-lg text-muted-foreground mb-8 text-pretty">
            Let's discuss your project and create a customized solution that meets your specific needs and budget.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild>
              <Link href="/contact">Get Free Consultation</Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/portfolio">View Portfolio</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
