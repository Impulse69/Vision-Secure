"use client"

import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ExternalLink, Eye } from "lucide-react"
import Link from "next/link"
import { useEffect, useRef, useState } from "react"

export default function PortfolioPage() {
  const heroRef = useRef<HTMLElement>(null)
  const portfolioRef = useRef<HTMLElement>(null)
  const [activeFilter, setActiveFilter] = useState("all")

  const portfolioItems = [
    {
      id: 1,
      title: "Corporate Security System",
      category: "security",
      description: "Complete CCTV installation for a 50,000 sq ft corporate facility with 24/7 monitoring.",
      image: "/modern-office-building-with-security-cameras.jpg",
      tags: ["CCTV", "Corporate", "24/7 Monitoring"],
    },
    {
      id: 2,
      title: "Brand Documentary",
      category: "media",
      description: "Professional documentary showcasing a tech startup's journey from concept to success.",
      image: "/professional-video-production-setup-with-cameras-a.jpg",
      tags: ["Documentary", "Corporate Video", "Storytelling"],
    },
    {
      id: 3,
      title: "Concert Sound Engineering",
      category: "sound",
      description: "Live sound production for a 5,000-person outdoor music festival with crystal-clear audio.",
      image: "/large-outdoor-concert-stage-with-professional-soun.jpg",
      tags: ["Live Sound", "Concert", "Audio Engineering"],
    },
    {
      id: 4,
      title: "Retail Security Network",
      category: "security",
      description: "Multi-location security system for retail chain with centralized monitoring dashboard.",
      image: "/modern-retail-store-with-discrete-security-cameras.jpg",
      tags: ["Retail", "Multi-location", "Remote Monitoring"],
    },
    {
      id: 5,
      title: "Product Launch Video",
      category: "media",
      description:
        "High-impact promotional video for tech product launch, featuring dynamic visuals and motion graphics.",
      image: "/professional-product-photography-setup-with-lighti.jpg",
      tags: ["Product Video", "Marketing", "Motion Graphics"],
    },
    {
      id: 6,
      title: "Podcast Studio Setup",
      category: "sound",
      description: "Complete audio production studio design and installation for professional podcast recording.",
      image: "/professional-podcast-recording-studio-with-microph.jpg",
      tags: ["Studio Design", "Podcast", "Acoustic Treatment"],
    },
  ]

  const filteredItems =
    activeFilter === "all" ? portfolioItems : portfolioItems.filter((item) => item.category === activeFilter)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in-up")
          }
        })
      },
      { threshold: 0.1 },
    )

    if (heroRef.current) observer.observe(heroRef.current)
    if (portfolioRef.current) observer.observe(portfolioRef.current)

    return () => observer.disconnect()
  }, [])

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />

      {/* Hero Section */}
      <section ref={heroRef} className="pt-24 pb-16 px-4 sm:px-6 lg:px-8 opacity-0">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6 text-balance">
            Our work speaks for
            <span className="text-primary block">itself</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8 text-pretty">
            Explore our portfolio of successful projects across security systems, media production, and sound
            engineering. Each project represents our commitment to excellence and innovation.
          </p>
        </div>
      </section>

      {/* Filter Tabs */}
      <section className="px-4 sm:px-6 lg:px-8 mb-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-wrap justify-center gap-4">
            <Button
              variant={activeFilter === "all" ? "default" : "outline"}
              onClick={() => setActiveFilter("all")}
              className="min-w-[120px]"
            >
              All Projects
            </Button>
            <Button
              variant={activeFilter === "security" ? "default" : "outline"}
              onClick={() => setActiveFilter("security")}
              className="min-w-[120px]"
            >
              Security
            </Button>
            <Button
              variant={activeFilter === "media" ? "default" : "outline"}
              onClick={() => setActiveFilter("media")}
              className="min-w-[120px]"
            >
              Media Production
            </Button>
            <Button
              variant={activeFilter === "sound" ? "default" : "outline"}
              onClick={() => setActiveFilter("sound")}
              className="min-w-[120px]"
            >
              Sound Production
            </Button>
          </div>
        </div>
      </section>

      {/* Portfolio Grid */}
      <section ref={portfolioRef} className="py-8 px-4 sm:px-6 lg:px-8 opacity-0">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredItems.map((item, index) => (
              <Card
                key={item.id}
                className="group hover:border-primary/50 transition-all duration-300 bg-card/50 backdrop-blur-sm overflow-hidden"
              >
                <div className="relative overflow-hidden">
                  <img
                    src={item.image || "/placeholder.svg"}
                    alt={item.title}
                    className="w-full h-64 object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <div className="flex gap-3">
                      <Button size="sm" variant="secondary" className="bg-background/90 hover:bg-background">
                        <Eye className="w-4 h-4 mr-2" />
                        View
                      </Button>
                      <Button size="sm" variant="secondary" className="bg-background/90 hover:bg-background">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Details
                      </Button>
                    </div>
                  </div>
                </div>
                <CardContent className="p-6">
                  <div className="flex flex-wrap gap-2 mb-3">
                    {item.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  <h3 className="text-xl font-bold text-foreground mb-3">{item.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed mb-4">{item.description}</p>
                  <Button variant="outline" size="sm" className="w-full bg-transparent">
                    Learn More
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-card/20">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Our Impact</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Numbers that reflect our commitment to delivering exceptional results across all our services.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-primary mb-2">500+</div>
              <div className="text-muted-foreground">Security Systems Installed</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-primary mb-2">200+</div>
              <div className="text-muted-foreground">Media Projects Completed</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-primary mb-2">150+</div>
              <div className="text-muted-foreground">Sound Productions</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-primary mb-2">98%</div>
              <div className="text-muted-foreground">Client Satisfaction Rate</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6 text-balance">
            Ready to create something extraordinary?
          </h2>
          <p className="text-lg text-muted-foreground mb-8 text-pretty">
            Let's discuss your project and see how we can bring your vision to life with our expertise and creativity.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild>
              <Link href="/contact">Start Your Project</Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/services">View Services</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
