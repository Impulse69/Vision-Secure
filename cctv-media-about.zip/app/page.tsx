import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Shield, Camera, Mic, Users, Award, Clock } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative pt-24 pb-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-background via-background/95 to-card/50"></div>
          <div className="absolute inset-0 bg-[url('/abstract-dark-technology-pattern.jpg')] opacity-5 bg-cover bg-center"></div>

          <div className="relative max-w-7xl mx-auto text-center">
            <div className="animate-fade-in-up">
              <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold text-foreground mb-8 text-balance leading-tight">
                VisionSecure
              </h1>
              <p className="text-xl md:text-2xl lg:text-3xl text-muted-foreground max-w-4xl mx-auto leading-relaxed text-pretty mb-12">
                Where cutting-edge security meets creative excellence. Professional CCTV solutions, media production,
                and sound services.
              </p>
            </div>

            <div className="animate-fade-in-up animate-delay-200 flex flex-col sm:flex-row gap-6 justify-center mb-16">
              <Button asChild size="lg" className="text-lg px-8 py-6">
                <Link href="/about">Discover Our Story</Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="text-lg px-8 py-6 bg-transparent">
                <Link href="/contact">Start Your Project</Link>
              </Button>
            </div>
          </div>
        </section>

        {/* Services Overview */}
        <section className="py-20 px-4 sm:px-6 lg:px-8 bg-card/30">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16 animate-fade-in-up">
              <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6 text-balance">Our Core Services</h2>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
                Three pillars of excellence driving innovation in security, creativity, and audio production.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <Card className="group hover:bg-accent/50 transition-all duration-300 animate-fade-in-up animate-delay-100">
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-primary/20 transition-colors">
                    <Shield className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="text-2xl font-bold text-foreground mb-4">CCTV Security</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Advanced surveillance systems with cutting-edge technology to protect what matters most to you.
                  </p>
                </CardContent>
              </Card>

              <Card className="group hover:bg-accent/50 transition-all duration-300 animate-fade-in-up animate-delay-200">
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-primary/20 transition-colors">
                    <Camera className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="text-2xl font-bold text-foreground mb-4">Media Production</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Professional videography and photography services that capture your vision with artistic excellence.
                  </p>
                </CardContent>
              </Card>

              <Card className="group hover:bg-accent/50 transition-all duration-300 animate-fade-in-up animate-delay-300">
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-primary/20 transition-colors">
                    <Mic className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="text-2xl font-bold text-foreground mb-4">Sound Production</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    High-quality audio solutions and sound engineering for events, studios, and installations.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Why Choose Us */}
        <section className="py-20 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16 animate-fade-in-up">
              <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6 text-balance">
                Why Choose VisionSecure
              </h2>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
                Experience the difference that professional expertise and cutting-edge technology can make.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center animate-fade-in-up animate-delay-100">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Users className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-4">Expert Team</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Certified professionals with years of experience in security, media, and audio production.
                </p>
              </div>

              <div className="text-center animate-fade-in-up animate-delay-200">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Award className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-4">Premium Equipment</h3>
                <p className="text-muted-foreground leading-relaxed">
                  State-of-the-art technology and equipment ensuring the highest quality results for every project.
                </p>
              </div>

              <div className="text-center animate-fade-in-up animate-delay-300">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Clock className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-4">24/7 Support</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Round-the-clock customer support and maintenance services to keep your systems running smoothly.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-primary/10 via-primary/5 to-accent/10">
          <div className="max-w-4xl mx-auto text-center animate-fade-in-up">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6 text-balance">
              Ready to Transform Your Vision?
            </h2>
            <p className="text-xl text-muted-foreground mb-8 text-pretty">
              Whether you need to secure your space or create something extraordinary, we're here to bring your vision
              to life.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="text-lg px-8 py-6">
                <Link href="/contact">Get Started Today</Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="text-lg px-8 py-6 bg-transparent">
                <Link href="/about">Learn More About Us</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
