"use client"

import { useEffect, useRef } from "react"
import Link from "next/link"
import { Shield, Camera, Volume2, Users, Award, Zap, ArrowRight, CheckCircle, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"

export default function AboutPage() {
  const observerRef = useRef<IntersectionObserver | null>(null)

  useEffect(() => {
    observerRef.current = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in-up")
          }
        })
      },
      { threshold: 0.1 },
    )

    const elements = document.querySelectorAll(".animate-on-scroll")
    elements.forEach((el) => observerRef.current?.observe(el))

    return () => observerRef.current?.disconnect()
  }, [])

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <div className="animate-fade-in-up">
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-foreground mb-6 text-balance">About Us</h1>
            <p className="text-xl md:text-2xl text-muted-foreground max-w-4xl mx-auto leading-relaxed text-pretty">
              Your trusted provider of cutting-edge CCTV security solutions, professional media services, and
              high-quality sound production. We combine innovation with expertise to deliver exceptional results.
            </p>
          </div>
        </div>
      </section>

      {/* Mission, Vision, Values */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="animate-on-scroll bg-card border-border hover:border-primary/50 transition-all duration-300">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <Shield className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-4">Security First</h3>
                <p className="text-muted-foreground leading-relaxed">
                  We are dedicated to providing comprehensive security solutions that protect what matters most to you.
                  Our advanced CCTV systems ensure peace of mind through reliable surveillance technology.
                </p>
              </CardContent>
            </Card>

            <Card className="animate-on-scroll bg-card border-border hover:border-primary/50 transition-all duration-300">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <Camera className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-4">Creative Excellence</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Our media production team brings stories to life through exceptional videography and photography. We
                  capture moments with artistic vision and technical precision.
                </p>
              </CardContent>
            </Card>

            <Card className="animate-on-scroll bg-card border-border hover:border-primary/50 transition-all duration-300">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <Volume2 className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-4">Audio Mastery</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Quality sound production is at the heart of every great project. We deliver crystal-clear audio
                  solutions that enhance every experience.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-secondary/20">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16 animate-on-scroll">
            <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-6 text-balance">Meet Our Expert Team</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
              Our diverse team of professionals brings years of experience and passion to every project
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="animate-on-scroll bg-card border-border hover:border-primary/50 transition-all duration-300">
              <CardContent className="p-8 text-center">
                <div className="w-24 h-24 bg-gradient-to-br from-primary/20 to-primary/5 rounded-full mx-auto mb-6 flex items-center justify-center">
                  <Users className="h-12 w-12 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-2">Alex Rodriguez</h3>
                <p className="text-primary font-medium mb-4">Security Systems Director</p>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  15+ years in security technology with expertise in advanced CCTV systems, access control, and
                  integrated security solutions.
                </p>
              </CardContent>
            </Card>

            <Card className="animate-on-scroll bg-card border-border hover:border-primary/50 transition-all duration-300">
              <CardContent className="p-8 text-center">
                <div className="w-24 h-24 bg-gradient-to-br from-primary/20 to-primary/5 rounded-full mx-auto mb-6 flex items-center justify-center">
                  <Camera className="h-12 w-12 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-2">Sarah Chen</h3>
                <p className="text-primary font-medium mb-4">Creative Director</p>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Award-winning filmmaker and photographer with a passion for storytelling through compelling visual
                  narratives and innovative production techniques.
                </p>
              </CardContent>
            </Card>

            <Card className="animate-on-scroll bg-card border-border hover:border-primary/50 transition-all duration-300">
              <CardContent className="p-8 text-center">
                <div className="w-24 h-24 bg-gradient-to-br from-primary/20 to-primary/5 rounded-full mx-auto mb-6 flex items-center justify-center">
                  <Volume2 className="h-12 w-12 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-2">Marcus Thompson</h3>
                <p className="text-primary font-medium mb-4">Audio Engineer</p>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Professional sound engineer specializing in studio recording, live sound production, and acoustic
                  design for optimal audio experiences.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16 animate-on-scroll">
            <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-6 text-balance">
              Why Choose VisionSecure
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
              We stand out through our commitment to excellence, innovation, and personalized service
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="animate-on-scroll flex items-start space-x-4">
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <Award className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-foreground mb-3">Professional Expertise</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Our certified professionals bring decades of combined experience across security, media production,
                  and audio engineering.
                </p>
              </div>
            </div>

            <div className="animate-on-scroll flex items-start space-x-4">
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <Zap className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-foreground mb-3">Cutting-Edge Equipment</h3>
                <p className="text-muted-foreground leading-relaxed">
                  We invest in the latest technology and equipment to ensure superior quality and reliability in every
                  project we undertake.
                </p>
              </div>
            </div>

            <div className="animate-on-scroll flex items-start space-x-4">
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-foreground mb-3">Personalized Service</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Every client receives tailored solutions designed to meet their specific needs, budget, and timeline
                  requirements.
                </p>
              </div>
            </div>

            <div className="animate-on-scroll flex items-start space-x-4">
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <CheckCircle className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-foreground mb-3">Quality Guarantee</h3>
                <p className="text-muted-foreground leading-relaxed">
                  We stand behind our work with comprehensive warranties and ongoing support to ensure your complete
                  satisfaction.
                </p>
              </div>
            </div>

            <div className="animate-on-scroll flex items-start space-x-4">
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <Star className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-foreground mb-3">Proven Track Record</h3>
                <p className="text-muted-foreground leading-relaxed">
                  With hundreds of successful projects and satisfied clients, our reputation speaks for itself in the
                  industry.
                </p>
              </div>
            </div>

            <div className="animate-on-scroll flex items-start space-x-4">
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <Shield className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-foreground mb-3">24/7 Support</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Our dedicated support team is available around the clock to address any concerns and ensure optimal
                  system performance.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Call-to-Action Banner */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-primary/10 via-primary/5 to-primary/10">
        <div className="max-w-7xl mx-auto text-center animate-on-scroll">
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-6 text-balance">
            Ready to secure your space or create something iconic?
          </h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto text-pretty">
            Let's discuss your project and discover how our expertise can bring your vision to life
          </p>
          <Button asChild size="lg" className="text-lg px-8 py-6">
            <Link href="/contact" className="inline-flex items-center space-x-2">
              <span>Contact Us Today</span>
              <ArrowRight className="h-5 w-5" />
            </Link>
          </Button>
        </div>
      </section>

      <Footer />
    </div>
  )
}
